Our section will accept requests from users around the world.
It will see what information the database already has about these requests.
It will also examine what information we're collecting about the request. 
We'll send a message to the user about what we have / what we're still collecting.
Then we send a message to administration to start a new job.
Talk to the visualization team to hopefully get organized data.
